/**
 * InsiEDR Telemetry Explorer Plugin
 * ==================================
 *
 * Architectural Role:
 *   High-throughput forensic telemetry exploration module. Enables analysts to
 *   query, multi-dimensionally filter, and inspect thousands of raw collector events
 *   with a windowed viewport and bounded DOM row count.
 *
 * Filter Pipeline:
 *   1. Server-Side: Applies filters before cursor pagination without exact counts.
 *   2. Debounced multi-dimensional filters across:
 *      - Time Range Cutoff: 15m, 1h, 24h, 7d rolling windows.
 *      - Status: success, warning, error, tampered.
 *      - Collector Domain: logon, file, usb/device, process, network/http.
 *      - Metadata Search: Hostname, username, collector; optional raw JSON search.
 *   3. Deep Inspection: Opens `LogInspectorDrawer` for structured key-value & raw JSON forensics.
 */

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { subscribeTelemetry } from '../../services/telemetryStream';
import type { PluginProps } from '../registry';
import { VirtualizedLogTable } from '../../components/telemetry/VirtualizedLogTable';
import { LogInspectorDrawer } from '../../components/telemetry/LogInspectorDrawer';
import { TelemetryHistogram } from '../../components/telemetry/TelemetryHistogram';
import { CollectorDatasetExportModal } from '../../components/telemetry/CollectorDatasetExportModal';
import { Button } from '../../components/ui/Button';
import type { TelemetryLog } from '../../types/telemetry';
import { fetchTelemetry, fetchTelemetryExplorer, fetchAvailableCollectors, exportTelemetryCSV, exportTelemetryJSON, triggerServerExport } from '../../services/api';
import {
  Search,
  X,
  Download,
  RefreshCw,
  SlidersHorizontal,
  Clock,
  ShieldAlert,
  Activity,
  Layers,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
} from 'lucide-react';

const KNOWN_COLLECTOR_LABELS: Record<string, string> = {
  all: 'All Watchers & Collectors',
  process: 'Process Watcher',
  network: 'Network Connections',
  logon: 'Logon & Authentication',
  file: 'File Integrity (FIM)',
  device: 'USB & Devices',
  http: 'HTTP & Web Traffic',
  'keystroke-collector': 'Keystroke Dynamics',
  'clipboard-monitor': 'Clipboard Monitor',
  driver_monitor: 'Driver Monitor',
  'driver-monitor': 'Driver Monitor',
  dns_monitor: 'DNS Queries',
  'dns-monitor': 'DNS Queries',
  lsass_monitor: 'LSASS Guard',
  'lsass-monitor': 'LSASS Guard',
  persistence_monitor: 'Persistence & Run Keys',
  'persistence-monitor': 'Persistence & Run Keys',
  registry: 'Registry Activity',
  usn_monitor: 'USN Journal Monitor',
  'usn-monitor': 'USN Journal Monitor',
  wmi_activity: 'WMI Activity',
  'wmi-activity': 'WMI Activity',
  'decoy-monitor': 'Decoy Canary Monitor',
  decoy_monitor: 'Decoy Canary Monitor',
  'memory-scanner': 'Memory Scanner',
  'short-Term_EDR_Feature': 'Short-Term Features',
};

const formatCollectorLabel = (key: string): string => {
  if (KNOWN_COLLECTOR_LABELS[key]) return KNOWN_COLLECTOR_LABELS[key];
  return key
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
};

export interface TelemetryExplorerPluginProps extends PluginProps {
  useExplorerApi?: boolean;
}

export const TelemetryExplorerPlugin: React.FC<TelemetryExplorerPluginProps> = ({ context, useExplorerApi = true }) => {
  const [logs, setLogs] = useState<TelemetryLog[]>(context.logs || []);
  const [selectedLog, setSelectedLog] = useState<TelemetryLog | null>(null);
  const [showCollectorExportModal, setShowCollectorExportModal] = useState<boolean>(false);
  const [availableCollectors, setAvailableCollectors] = useState<string[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Filters State
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCollector, setActiveCollector] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<string>('1h');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [searchScope, setSearchScope] = useState<'metadata' | 'payload'>('metadata');
  const [loadError, setLoadError] = useState<string | null>(null);
  const request = useRef<AbortController | null>(null);
  const queuedRefresh = useRef(false);
  const scheduleRefresh = useRef<() => void>(() => {});
  const pageCursors = useRef<(string | undefined)[]>([undefined]);
  const queryStart = useRef<string | undefined>(undefined);
  const displayedQuery = useRef('');
  const [source, setSource] = useState('postgres');
  const [isExportingStream, setIsExportingStream] = useState<boolean>(false);

  useEffect(() => {
    fetchAvailableCollectors()
      .then((res) => {
        if (res.ok && Array.isArray(res.collectors) && res.collectors.length > 0) {
          setAvailableCollectors(res.collectors);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebouncedSearch(searchTerm.trim()), 250);
    return () => window.clearTimeout(timer);
  }, [searchTerm]);

  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(50);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [hasMore, setHasMore] = useState<boolean>(true);

  const loadLogs = useCallback(
    async (pageToLoad = 1, currentSize = pageSize, background = false) => {
      if (background && request.current) { queuedRefresh.current = true; return; }
      const key = JSON.stringify([activeCollector, debouncedSearch, statusFilter, timeRange, currentSize, searchScope]);
      if (displayedQuery.current !== key) {
        setLogs([]);
        setLastUpdated(null);
        setCurrentPage(1);
        setHasMore(false);
        displayedQuery.current = key;
      }
      request.current?.abort();
      const abort = new AbortController();
      request.current = abort;
      if (background) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      const periods: Record<string, number> = { '15m': 900, '1h': 3600, '24h': 86400, '7d': 604800 };
      if (pageToLoad === 1) {
        pageCursors.current = [undefined];
        queryStart.current = periods[timeRange] ? new Date(Date.now() - periods[timeRange] * 1000).toISOString() : undefined;
      }
      try {
        let fetched: TelemetryLog[] = [];
        let nextCursorVal: string | undefined = undefined;
        let hasMoreVal = false;
        let sourceVal = 'postgres';

        if (useExplorerApi) {
          const response = await fetchTelemetryExplorer(currentSize, pageCursors.current[pageToLoad - 1],
            activeCollector === 'all' ? null : activeCollector, null, {
              search: debouncedSearch || undefined,
              status: statusFilter === 'all' ? undefined : statusFilter,
              start_time: queryStart.current,
              include_total: false,
              search_scope: searchScope,
              offset: 0,
              signal: abort.signal,
            });
          if (abort.signal.aborted || request.current !== abort) return;
          if (!response.ok) throw new Error('Telemetry is temporarily unavailable');
          fetched = (response.events || response.logs || []) as TelemetryLog[];
          nextCursorVal = response.next_cursor || undefined;
          hasMoreVal = Boolean(response.has_more && response.next_cursor);
          sourceVal = response.source || 'clickhouse';
        } else {
          const response = await fetchTelemetry(currentSize, 0,
            activeCollector === 'all' ? null : activeCollector, null, {
              search: debouncedSearch || undefined,
              status: statusFilter === 'all' ? undefined : statusFilter,
              start_time: queryStart.current,
              cursor: pageCursors.current[pageToLoad - 1],
              include_total: false,
              search_scope: searchScope,
              signal: abort.signal,
            });
          if (abort.signal.aborted || request.current !== abort) return;
          if (!response.ok) throw new Error('Telemetry is temporarily unavailable');
          fetched = response.logs || [];
          nextCursorVal = response.next_cursor || undefined;
          hasMoreVal = Boolean(response.has_more && response.next_cursor);
          sourceVal = response.source || 'postgres';
        }

        setLogs(fetched);
        setCurrentPage(pageToLoad);
        pageCursors.current[pageToLoad] = nextCursorVal;
        setHasMore(hasMoreVal);
        setSource(sourceVal);
        setLoadError(null);
        setLastUpdated(new Date());
      } catch (error) {
        if (!abort.signal.aborted) {
          const errMsg = error instanceof Error ? error.message : 'Could not load telemetry';
          setLoadError(errMsg);
        }
      } finally {
        if (request.current === abort) {
          request.current = null;
          setIsLoading(false);
          setIsRefreshing(false);
          if (queuedRefresh.current) { queuedRefresh.current = false; scheduleRefresh.current(); }
        }
      }
    }, [activeCollector, debouncedSearch, statusFilter, timeRange, pageSize, searchScope, useExplorerApi]
  );

  useEffect(() => {
    void loadLogs(1, pageSize);
    return () => { request.current?.abort(); request.current = null; queuedRefresh.current = false; };
  }, [loadLogs, pageSize]);

  useEffect(() => {
    if (context.autoRefresh === false || currentPage !== 1 || selectedLog) return;
    // Immediate refresh on resume/mount if on page 1
    void loadLogs(1, pageSize, true);

    let timer: number | undefined;
    const schedule = () => {
      if (timer !== undefined) return;
      timer = window.setTimeout(() => {
        timer = undefined;
        if (document.visibilityState === 'visible') void loadLogs(1, pageSize, true);
      }, 500);
    };
    scheduleRefresh.current = schedule;
    const unsubscribe = subscribeTelemetry(schedule);
    // Active polling interval: 4s when polling fallback, 10s when SSE connected
    const pollInterval = context.isConnected ? 10000 : 4000;
    const poll = window.setInterval(schedule, pollInterval);
    const onVisible = () => { if (document.visibilityState === 'visible') schedule(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      unsubscribe();
      window.clearInterval(poll);
      window.clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisible);
      queuedRefresh.current = false;
      scheduleRefresh.current = () => {};
    };
  }, [context.autoRefresh, context.isConnected, currentPage, pageSize, loadLogs, selectedLog]);

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize);

  };

  const handleGoToPage = (newPage: number) => {
    if (newPage < 1 || (newPage > 1 && !pageCursors.current[newPage - 1]) || isLoading) return;
    loadLogs(newPage, pageSize);
  };

  const startItem = logs.length === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const endItem = (currentPage - 1) * pageSize + logs.length;

  // Filters run before database pagination, so rows and totals share semantics.
  const filteredLogs = logs;

  const collectorOptions = useMemo(() => {
    const defaultList = [
      'all',
      'process',
      'network',
      'logon',
      'file',
      'device',
      'http',
      'keystroke-collector',
      'clipboard-monitor',
      'driver_monitor',
      'dns_monitor',
      'lsass_monitor',
      'persistence_monitor',
      'registry',
      'usn_monitor',
      'wmi_activity',
      'decoy-monitor',
    ];
    const combined = [...defaultList];
    for (const c of availableCollectors) {
      if (!combined.includes(c)) {
        combined.push(c);
      }
    }
    return combined;
  }, [availableCollectors]);

  const handleClearAllFilters = () => {
    setSearchTerm('');
    setActiveCollector('all');
    setStatusFilter('all');
    setTimeRange('all');
  };

  const handleStreamAllExport = async () => {
    try {
      setIsExportingStream(true);
      await triggerServerExport('logs', 'csv', {
        collector: activeCollector === 'all' ? undefined : activeCollector,
        status: statusFilter === 'all' ? undefined : statusFilter,
        search: debouncedSearch || undefined,
        start_time: queryStart.current,
      });
    } catch (err) {
      console.error('Streaming export failed:', err);
    } finally {
      setIsExportingStream(false);
    }
  };

  const hasActiveFilters =
    Boolean(searchTerm.trim()) ||
    activeCollector !== 'all' ||
    statusFilter !== 'all' ||
    timeRange !== 'all';

  return (
    <div className="space-y-6">
      {loadError && (
        <div role="alert" className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          {loadError}{logs.length > 0 ? '. Displaying the last successfully loaded page.' : ''}
          <button type="button" onClick={() => loadLogs(currentPage, pageSize)} className="ml-3 underline">Retry</button>
        </div>
      )}

      {/* Server-Side Event Frequency Histogram (ClickHouse Aggregation) */}
      <TelemetryHistogram
          autoRefresh={context.autoRefresh}
        refreshVersion={lastUpdated ? Math.floor(lastUpdated.getTime() / 15000) : undefined}
        timeRange={timeRange}
        activeCollector={activeCollector}
        statusFilter={statusFilter}
      />

      {/* Comprehensive Filter Toolbar */}
      <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-[0_1px_3px_rgba(0,0,0,0.06)] space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              aria-label="Search telemetry"
              placeholder={searchScope === 'metadata' ? 'Search hostname, user, or collector...' : 'Search metadata and raw payload...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-8 h-[38px] text-xs bg-white border border-slate-200 rounded-md outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-slate-900 transition-colors shadow-2xs"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter Selectors */}
          <div className="flex items-center gap-2 flex-wrap">
            <select aria-label="Search scope" value={searchScope}
              onChange={(event) => setSearchScope(event.target.value as 'metadata' | 'payload')}
              className="bg-white border border-slate-200 rounded-md px-3 h-[38px] text-xs">
              <option value="metadata">Metadata search</option>
              <option value="payload">Include payload (slower)</option>
            </select>
            {/* Collector Dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md px-3 h-[38px] text-xs shadow-2xs">
              <Activity className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-500 font-medium">Collector:</span>
              <select
                aria-label="Collector"
                value={activeCollector}
                onChange={(e) => setActiveCollector(e.target.value)}
                className="bg-transparent font-medium text-slate-800 outline-none cursor-pointer max-w-[220px]"
              >
                {collectorOptions.map((collectorKey) => (
                  <option key={collectorKey} value={collectorKey}>
                    {formatCollectorLabel(collectorKey)}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md px-3 h-[38px] text-xs shadow-2xs">
              <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-500 font-medium">Status:</span>
              <select
                aria-label="Status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-transparent font-medium text-slate-800 outline-none cursor-pointer"
              >
                <option value="all">All Statuses</option>
                <option value="success">Success / Normal</option>
                <option value="warning">Warning</option>
                <option value="error">Error / Tampered</option>
              </select>
            </div>

            {/* Time Window Dropdown */}
            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-md px-3 h-[38px] text-xs shadow-2xs">
              <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="text-slate-500 font-medium">Time:</span>
              <select
                aria-label="Time range"
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="bg-transparent font-medium text-slate-800 outline-none cursor-pointer"
              >
                <option value="all">All retained logs (chart: 30 days)</option>
                <option value="15m">Last 15 Minutes</option>
                <option value="1h">Last 1 Hour</option>
                <option value="24h">Last 24 Hours</option>
                <option value="7d">Last 7 Days</option>
              </select>
            </div>
          </div>

          {/* Export & Refresh Actions */}
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => exportTelemetryCSV(filteredLogs)}
              icon={<Download className="w-3.5 h-3.5" />}
              title="Export filtered logs currently loaded to CSV"
            >
              CSV
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => exportTelemetryJSON(filteredLogs)}
              icon={<Download className="w-3.5 h-3.5" />}
              title="Export filtered logs currently loaded to JSON"
            >
              JSON
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleStreamAllExport}
              disabled={isExportingStream}
              icon={<Download className={`w-3.5 h-3.5 ${isExportingStream ? 'animate-bounce' : ''}`} />}
              title="Stream full server telemetry dataset matching active filters (CSV)"
            >
              {isExportingStream ? 'Streaming...' : 'Stream All'}
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => setShowCollectorExportModal(true)}
              icon={<Layers className="w-3.5 h-3.5 text-indigo-600" />}
              title="Export single collector dataset with unrolled feature columns"
            >
              Collector Dataset
            </Button>
            {/* Pipeline Polling Toggle Button */}
            {context.onToggleAutoRefresh && (
              <Button
                variant={context.autoRefresh !== false ? 'secondary' : 'primary'}
                size="sm"
                onClick={context.onToggleAutoRefresh}
                title={
                  context.autoRefresh !== false
                    ? 'Click to pause pipeline and stop receiving new logs'
                    : 'Click to start pipeline and receive new logs'
                }
                className={
                  context.autoRefresh !== false
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-900 hover:bg-emerald-100 font-medium'
                    : 'bg-slate-900 text-white hover:bg-slate-800 font-medium'
                }
                icon={
                  context.autoRefresh !== false ? (
                    <span className="relative flex h-2 w-2 mr-0.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                    </span>
                  ) : (
                    <span className="h-2 w-2 rounded-full bg-slate-400 mr-0.5" />
                  )
                }
              >
                {context.autoRefresh !== false ? 'Pipeline: Receiving' : 'Pipeline: Paused'}
              </Button>
            )}
            <Button
              variant="secondary"
              size="sm"
              onClick={() => loadLogs(1, pageSize)}
              disabled={isLoading}
              icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading || isRefreshing ? 'animate-spin' : ''}`} />}
            >
              Refresh
            </Button>
          </div>
        </div>

        {/* Filter Badges & Live Record Counter */}
        <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            {hasActiveFilters ? (
              <>
                <span className="text-slate-500 font-medium flex items-center gap-1">
                  <SlidersHorizontal className="w-3 h-3" />
                  Active Filters:
                </span>

                {searchTerm.trim() && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                    Search: "{searchTerm}"
                    <button onClick={() => setSearchTerm('')} className="hover:text-slate-900 cursor-pointer">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                )}

                {activeCollector !== 'all' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 font-medium">
                    Collector: {formatCollectorLabel(activeCollector)}
                    <button onClick={() => setActiveCollector('all')} className="hover:text-blue-900 cursor-pointer">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                )}

                {statusFilter !== 'all' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                    Status: {statusFilter.toUpperCase()}
                    <button onClick={() => setStatusFilter('all')} className="hover:text-amber-950 cursor-pointer">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                )}

                {timeRange !== 'all' && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200 font-medium">
                    Window: {timeRange}
                    <button onClick={() => setTimeRange('all')} className="hover:text-purple-900 cursor-pointer">
                      <X className="w-2.5 h-2.5" />
                    </button>
                  </span>
                )}

                <button
                  onClick={handleClearAllFilters}
                  className="text-blue-600 hover:text-blue-800 font-medium underline underline-offset-2 ml-1 cursor-pointer"
                >
                  Clear all
                </button>
              </>
            ) : (
              <span className="text-slate-500 font-medium flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-blue-500" />
                <span>All Collectors ({collectorOptions.length - 1} sources available)</span>
              </span>
            )}
          </div>

          <div className="text-slate-600 font-medium flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-md shadow-2xs">
            <span className="text-slate-400 font-normal">Records:</span>
            <span className="text-slate-900 font-mono font-semibold">
              {filteredLogs.length} loaded
            </span>
            <span className="text-slate-400 font-normal">/</span>
            <span className="text-blue-600 font-mono font-bold">
              {source === 'clickhouse' ? 'Analytics replica' : 'Live telemetry'}
            </span>
            {lastUpdated && (
              <>
                <span className="text-slate-300">|</span>
                <span className="text-slate-400 font-normal text-[11px]" title={`Last updated at ${lastUpdated.toLocaleTimeString()}`}>
                  Updated {lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Virtualized Table */}
      <VirtualizedLogTable
        logs={filteredLogs}
        resetKey={`${activeCollector}:${debouncedSearch}:${statusFilter}:${timeRange}:${currentPage}:${pageSize}`}
        onSelectLog={(log) => setSelectedLog(log)}
        isLoading={isLoading}
        error={loadError}
        onRetry={() => loadLogs(currentPage, pageSize)}
      />

      {/* Interactive Pagination Bar */}
      <div className="bg-white border border-slate-200 rounded-lg p-3.5 flex flex-wrap items-center justify-between gap-4 shadow-2xs text-xs">
        {/* Left: Rows Per Page Selector & Record Range Summary */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5 text-slate-600">
            <span className="font-medium">Rows per page:</span>
            <select
              value={pageSize}
              onChange={(e) => handlePageSizeChange(Number(e.target.value))}
              disabled={isLoading}
              className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1 font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 cursor-pointer text-xs shadow-2xs"
            >
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={200}>200</option>
            </select>
          </div>

          <span className="text-slate-300">|</span>

          <div className="text-slate-600 font-medium">
            Showing <b className="text-slate-900 font-mono">{startItem}</b> –{' '}
            <b className="text-slate-900 font-mono">{endItem}</b>{' '}
            records {hasMore ? '(more available)' : '(end of results)'}
          </div>
        </div>

        {/* Right: Page Navigation Controls */}
        <div className="flex items-center gap-1">
          {/* First Page */}
          <Button
            variant="secondary"
            size="sm"
            onClick={() => handleGoToPage(1)}
            disabled={currentPage <= 1 || isLoading}
            title="First Page (Page 1)"
            className="px-2"
          >
            <ChevronsLeft className="w-4 h-4" />
          </Button>

          {/* Previous Page */}
          <Button
            variant="secondary"
            size="sm"
            onClick={() => handleGoToPage(currentPage - 1)}
            disabled={currentPage <= 1 || isLoading}
            title="Previous Page"
            className="px-2.5"
          >
            <ChevronLeft className="w-4 h-4 mr-0.5" />
            Prev
          </Button>

          {/* Page Numbers */}
          <div className="flex items-center gap-1 px-1">
            <span aria-live="polite" className="px-2 font-mono">Page {currentPage}</span>
          </div>

          {/* Next Page */}
          <Button
            variant="secondary"
            size="sm"
            onClick={() => handleGoToPage(currentPage + 1)}
            disabled={!hasMore || isLoading}
            title="Next Page"
            className="px-2.5"
          >
            Next
            <ChevronRight className="w-4 h-4 ml-0.5" />
          </Button>

        </div>
      </div>

      {/* Payload Inspector Drawer */}
      <LogInspectorDrawer
        log={selectedLog}
        onClose={() => setSelectedLog(null)}
      />

      {/* Collector-Specific Dataset Export Modal */}
      <CollectorDatasetExportModal
        isOpen={showCollectorExportModal}
        onClose={() => setShowCollectorExportModal(false)}
        defaultCollector={activeCollector !== 'all' ? activeCollector : 'logon'}
        defaultUsername={searchTerm.trim() || undefined}
      />
    </div>
  );
};
