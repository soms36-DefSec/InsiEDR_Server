"""Opt-in analytics pages for the legacy ClickHouse schema.

Deduplicate replayed rows before LIMIT/count. This compatibility path still
needs a raw-payload join for username; see the audit's denormalized v2 design.
"""
import json
import logging
from typing import Any
from datetime import datetime, timezone

from server.storage.telemetry_cursor import filter_key, encode_cursor, decode_cursor

logger = logging.getLogger(__name__)


def _utc_iso(value: Any) -> str:
    """ClickHouse DateTime64 values are UTC even when the driver returns naive datetimes."""
    if isinstance(value, datetime):
        return value.replace(tzinfo=timezone.utc).isoformat() if value.tzinfo is None else value.astimezone(timezone.utc).isoformat()
    raw = str(value or '').replace(' ', 'T')
    if not raw:
        return raw
    if raw.endswith('Z') or '+' in raw[10:] or '-' in raw[10:]:
        return raw
    return raw + 'Z'


def telemetry_page(storage, limit=100, offset=0, collector=None, username=None,
                   status=None, search=None, start_time=None, end_time=None,
                   include_enrichment=True, cursor=None, include_total=True,
                   search_scope='payload'):
    if search_scope not in ('metadata', 'payload'):
        raise ValueError('Invalid search scope')
    if cursor and offset:
        raise ValueError('cursor and offset cannot be combined')
    version2 = getattr(storage, 'collector_schema_version', 1) == 2
    cursor_source = 'clickhouse-v2' if version2 else 'clickhouse'
    username_column = 'cr.username' if version2 else 'rp.username'
    received_column = 'cr.received_at' if version2 else 'rp.received_at'
    key = filter_key(collector=collector, username=username, status=status, search=search,
                     start_time=start_time, end_time=end_time, search_scope=search_scope)
    params, clauses = {}, []

    def contains(column, value):
        name = f'p{len(params)}'
        params[name] = value
        return f'positionCaseInsensitiveUTF8({column}, %({name})s) > 0'

    if collector:
        clean = collector.strip().lower()
        base = clean
        for suffix in ('-monitor', '_monitor', '-collector', '_collector', '-watcher', '_watcher'):
            base = base.replace(suffix, '')
        aliases = {'device': ['device', 'usb'], 'usb': ['usb', 'device'], 'http': ['http', 'browser']}
        known = {'network', 'process', 'file', 'logon', 'keystroke', 'clipboard', 'dns',
                 'driver', 'lsass', 'persistence', 'registry', 'usn', 'wmi', 'decoy', 'memory'}
        terms = aliases.get(base, [base] if base in known else [clean, clean.replace('_', '-'), clean.replace('-', '_')])
        clauses.append('(' + ' OR '.join(contains('cr.collector', term) for term in terms) + ')')
    if username:
        clauses.append(contains(username_column, username))
    if status:
        params['statuses'] = ['error', 'failed', 'critical', 'tampered'] if status == 'error' else [status]
        clauses.append('lower(cr.status) IN %(statuses)s')
    if search:
        columns = ['cr.hostname', username_column, 'cr.collector']
        if search_scope == 'payload':
            columns.append('cr.payload_json')
        clauses.append('(' + ' OR '.join(contains(column, search) for column in columns) + ')')
    for name, value, operator in [('start', start_time, '>='), ('end', end_time, '<=')]:
        if value:
            params[name] = str(value)
            clauses.append(f"cr.collector_collected_at {operator} parseDateTime64BestEffort(%({name})s, 3, 'UTC')")
    if cursor:
        timestamp, row_id = decode_cursor(cursor, cursor_source, key)
        if timestamp is None:
            raise ValueError('ClickHouse cursors require a timestamp')
        params.update(cursor_time=timestamp, cursor_id=row_id)
        clauses.append("(cr.collector_collected_at, cr.id) < (parseDateTime64BestEffort(%(cursor_time)s, 3, 'UTC'), toUUID(%(cursor_id)s))")
    where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
    count_where = where

    # Push down filters on collector_results to prevent unbounded DISTINCT over memory
    cr_clauses = [c.replace('cr.', '') for c in clauses if 'rp.' not in c]
    cr_sub_where = (' WHERE ' + ' AND '.join(cr_clauses)) if cr_clauses else ''

    rp_dependent = any('rp.' in c for c in clauses)
    inner_limit_clause = ''
    if not rp_dependent and not version2:
        params['inner_limit'] = limit + offset + 1
        inner_limit_clause = ' ORDER BY collector_collected_at DESC, id DESC LIMIT %(inner_limit)s'

    if cr_sub_where or inner_limit_clause:
        rp_filter = f' WHERE payload_id IN (SELECT payload_id FROM (SELECT id, payload_id, collector_collected_at FROM collector_results{cr_sub_where}{inner_limit_clause}))'
    else:
        rp_filter = ''

    # The legacy writer emits deterministic IDs but MergeTree does not enforce
    # uniqueness. DISTINCT also prevents replay from changing page boundaries.
    source = f''' FROM (SELECT DISTINCT id, payload_id, agent_id, collector,
        collector_collected_at, hostname, status, payload_json FROM collector_results{cr_sub_where}{inner_limit_clause}) cr
        LEFT JOIN (SELECT payload_id, argMin(username, received_at) AS username,
        min(received_at) AS received_at FROM raw_payloads{rp_filter} GROUP BY payload_id) rp
        ON cr.payload_id = rp.payload_id'''
    if version2:
        source = ' FROM (SELECT * FROM collector_events_v2 FINAL) cr'
    params.update(limit=limit + 1, offset=offset)
    result = storage._query(f'''SELECT cr.id, cr.payload_id, cr.agent_id, cr.collector,
        cr.collector_collected_at AS collected_at, cr.hostname, {username_column} AS username,
        cr.status, cr.payload_json AS payload, {received_column} AS received_at''' + source + where +
        ' ORDER BY cr.collector_collected_at DESC, cr.id DESC LIMIT %(limit)s OFFSET %(offset)s', params)
    logs = [dict(zip(result.column_names, row)) for row in result.result_rows]
    has_more = len(logs) > limit
    logs = logs[:limit]
    next_cursor = encode_cursor(cursor_source, key, logs[-1]['collected_at'], logs[-1]['id']) if has_more else None
    for row in logs:
        row['id'] = str(row['id'])
        if isinstance(row['payload'], str):
            try:
                row['payload'] = json.loads(row['payload'])
            except ValueError:
                pass
        row['summary_preview'] = extract_summary_preview(row.get('collector'), row.get('payload'))
    total = None
    if include_total:
        if version2:
            total = storage._query('SELECT count()' + source + count_where, params).result_rows[0][0]
        elif not rp_dependent:
            total = storage._query(f'SELECT count(DISTINCT id) FROM collector_results{cr_sub_where}', params).result_rows[0][0]
        else:
            total = storage._query('SELECT count()' + source + count_where, params).result_rows[0][0]
    if include_enrichment and logs:
        ids = list(dict.fromkeys(row['payload_id'] for row in logs))
        result = storage._query('''SELECT payload_id,
            argMax(tuple(risk_level, summary, correlated_signals_json, risk_score), (created_at, id))
            FROM risk_events WHERE payload_id IN %(ids)s GROUP BY payload_id''', {'ids': ids})
        fields = ('risk_level', 'summary', 'correlated_signals_json', 'risk_score')
        risks = {row[0]: dict(zip(fields, row[1])) for row in result.result_rows}
        for row in logs:
            row.update(risks.get(row['payload_id'], dict.fromkeys(fields)))
    return {'logs': logs, 'total': total, 'offset': offset, 'limit': limit,
            'has_more': has_more, 'next_cursor': next_cursor, 'source': 'clickhouse'}


def extract_summary_preview(collector_name: str | None, payload_obj: Any) -> str:
    """Derive a concise human-readable summary preview (<= 150 chars) from payload."""
    if not payload_obj:
        return f"{collector_name or 'Telemetry'} observation"
    if isinstance(payload_obj, str):
        try:
            payload_obj = json.loads(payload_obj)
        except Exception:
            return payload_obj[:120]
    if not isinstance(payload_obj, dict):
        return str(payload_obj)[:120]

    # Unwrap envelope if nested
    if 'payload' in payload_obj and isinstance(payload_obj['payload'], dict) and 'status' in payload_obj:
        payload_obj = payload_obj['payload']

    col = (collector_name or '').lower()
    if 'process' in col:
        pname = payload_obj.get('process_name') or payload_obj.get('name') or payload_obj.get('image') or payload_obj.get('cmd')
        pid = payload_obj.get('pid') or payload_obj.get('process_id')
        cmd = payload_obj.get('command_line') or payload_obj.get('cmdline')
        if pname and pid:
            return f"Process: {pname} (PID: {pid})"
        if cmd:
            return f"Cmd: {str(cmd)[:80]}"
        if pname:
            return f"Process: {pname}"
    elif 'network' in col or 'http' in col or 'dns' in col:
        dest = payload_obj.get('dest_ip') or payload_obj.get('remote_ip') or payload_obj.get('host') or payload_obj.get('url') or payload_obj.get('domain')
        port = payload_obj.get('dest_port') or payload_obj.get('port')
        method = payload_obj.get('method')
        proto = payload_obj.get('proto') or payload_obj.get('protocol')
        if method and dest:
            return f"HTTP {method}: {dest}"
        if dest and port:
            return f"Conn: {dest}:{port} ({proto or 'TCP'})"
        if dest:
            return f"Net: {dest}"
    elif 'file' in col:
        path = payload_obj.get('path') or payload_obj.get('file_path') or payload_obj.get('target')
        act = payload_obj.get('action') or payload_obj.get('event_type') or 'Access'
        if path:
            return f"File {act}: {path}"
    elif 'logon' in col:
        user = payload_obj.get('user') or payload_obj.get('username') or payload_obj.get('target_user')
        auth = payload_obj.get('auth_type') or payload_obj.get('logon_type') or 'interactive'
        if user:
            return f"Logon: {user} ({auth})"
    elif 'usb' in col or 'device' in col:
        dev = payload_obj.get('device_name') or payload_obj.get('device_id') or payload_obj.get('vendor')
        if dev:
            return f"Device: {dev}"
    elif 'tamper' in col or 'lsass' in col:
        reason = payload_obj.get('reason') or payload_obj.get('signal') or payload_obj.get('alert')
        if reason:
            return f"Alert: {reason}"

    # Generic preview from top keys
    pairs = []
    for k, v in payload_obj.items():
        if k in ('token', 'secret', 'password', 'key'):
            continue
        if isinstance(v, (str, int, float, bool)):
            pairs.append(f"{k}={v}")
        if len(pairs) >= 3:
            break
    if pairs:
        return ", ".join(pairs)[:120]
    return f"{collector_name or 'Event'} observation"


def telemetry_explorer(storage, limit=50, cursor=None, collector=None, username=None,
                       status=None, search=None, start_time=None, end_time=None,
                       agent_id=None):
    """
    Projected Split-View List Query for Industrial EDR Telemetry.
    Selects ONLY 5 lightweight scalar columns (event_id, timestamp, agent_id, collector_name, summary_preview)
    plus tabular metadata (hostname, username, status).
    Zero nested raw payload objects returned: response size < 20KB for 50 rows.
    Deterministic seek/cursor pagination via primary index.
    """
    key = filter_key(collector=collector, username=username, status=status, search=search,
                     start_time=start_time, end_time=end_time, agent_id=agent_id, scope='explorer')
    params, clauses = {}, []

    def contains(column, value):
        name = f"p{len(params)}"
        params[name] = value
        return f"positionCaseInsensitiveUTF8({column}, %({name})s) > 0"

    if agent_id:
        params['agent_id'] = str(agent_id)
        clauses.append("agent_id = %(agent_id)s")

    if collector:
        clean = collector.strip().lower()
        base = clean
        for suffix in ('-monitor', '_monitor', '-collector', '_collector', '-watcher', '_watcher'):
            base = base.replace(suffix, '')
        aliases = {'device': ['device', 'usb'], 'usb': ['usb', 'device'], 'http': ['http', 'browser']}
        known = {'network', 'process', 'file', 'logon', 'keystroke', 'clipboard', 'dns',
                 'driver', 'lsass', 'persistence', 'registry', 'usn', 'wmi', 'decoy', 'memory'}
        terms = aliases.get(base, [base] if base in known else [clean, clean.replace('_', '-'), clean.replace('-', '_')])
        clauses.append('(' + ' OR '.join(contains('collector_name', term) for term in terms) + ')')

    if username:
        clauses.append(contains('username', username))

    if status:
        params['statuses'] = ['error', 'failed', 'critical', 'tampered'] if status == 'error' else [status]
        clauses.append('lower(status) IN %(statuses)s')

    if search:
        clauses.append('(' + ' OR '.join(contains(col, search) for col in ['hostname', 'username', 'collector_name', 'summary_preview']) + ')')

    for name, value, operator in [('start', start_time, '>='), ('end', end_time, '<=')]:
        if value:
            params[name] = str(value)
            clauses.append(f"timestamp {operator} parseDateTime64BestEffort(%({name})s, 3, 'UTC')")

    if cursor:
        timestamp, row_id = decode_cursor(cursor, 'clickhouse', key)
        if timestamp is None:
            raise ValueError('ClickHouse cursors require a timestamp')
        params.update(cursor_time=timestamp, cursor_id=row_id)
        clauses.append("(timestamp, event_id) < (parseDateTime64BestEffort(%(cursor_time)s, 3, 'UTC'), toUUID(%(cursor_id)s))")
    elif not start_time:
        # Default partition bound for unpaged initial query: prune older monthly parts
        clauses.append("timestamp >= now() - INTERVAL 30 DAY")

    where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
    params['limit'] = limit + 1

    events = []
    # Primary attempt: Query dedicated telemetry_events table
    try:
        sql = (
            "SELECT event_id, timestamp, agent_id, collector_name, hostname, username, status, summary_preview "
            "FROM telemetry_events" + where + " "
            "ORDER BY timestamp DESC, event_id DESC "
            "LIMIT %(limit)s"
        )
        res = storage._query(sql, params)
        if res and hasattr(res, 'result_rows'):
            for row in res.result_rows:
                d = dict(zip(res.column_names, row))
                eid = str(d.get('event_id', ''))
                ts = d.get('timestamp')
                ts_str = _utc_iso(ts)
                cname = str(d.get('collector_name') or '')
                events.append({
                    'event_id': eid,
                    'id': eid,
                    'timestamp': ts_str,
                    'collected_at': ts_str,
                    'agent_id': str(d.get('agent_id') or ''),
                    'collector_name': cname,
                    'collector': cname,
                    'hostname': str(d.get('hostname') or ''),
                    'username': str(d.get('username') or ''),
                    'status': str(d.get('status') or 'success'),
                    'summary_preview': str(d.get('summary_preview') or ''),
                })
    except Exception:
        events = []

    # Fallback to collector_events_v2 / collector_results if telemetry_events table is empty or unpopulated
    if not events:
        try:
            fb_clauses = []
            fb_params = dict(params)
            version2 = getattr(storage, 'collector_schema_version', 1) == 2
            for c in clauses:
                fb_c = (c.replace('collector_name', 'cr.collector')
                         .replace('summary_preview', 'cr.payload_json')
                         .replace('timestamp', 'cr.collector_collected_at')
                         .replace('event_id', 'cr.id'))
                if not version2:
                    import re
                    fb_c = re.sub(
                        r'positionCaseInsensitiveUTF8\(username,\s*(%\([^)]+\)s)\)\s*>\s*0',
                        r'cr.payload_id IN (SELECT payload_id FROM raw_payloads WHERE positionCaseInsensitiveUTF8(username, \1) > 0)',
                        fb_c
                    )
                fb_clauses.append(fb_c)
            fb_where = (' WHERE ' + ' AND '.join(fb_clauses)) if fb_clauses else ''
            if version2:
                source = ' FROM (SELECT * FROM collector_events_v2 FINAL) cr '
                username_col = 'cr.username'
                fb_sql = (
                    f"SELECT cr.id AS event_id, cr.payload_id, cr.collector_collected_at AS timestamp, cr.agent_id, cr.collector AS collector_name, "
                    f"cr.hostname, {username_col} AS username, cr.status, cr.payload_json "
                    + source + fb_where + " "
                    + "ORDER BY cr.collector_collected_at DESC, cr.id DESC LIMIT %(limit)s"
                )
            else:
                source = (
                    f" FROM (SELECT cr.id, cr.payload_id, cr.agent_id, cr.collector, cr.collector_collected_at, "
                    f"cr.hostname, cr.status, cr.payload_json FROM collector_results cr{fb_where} "
                    f"ORDER BY cr.collector_collected_at DESC, cr.id DESC LIMIT %(limit)s) cr "
                )
                username_col = "''"
                fb_sql = (
                    f"SELECT cr.id AS event_id, cr.payload_id, cr.collector_collected_at AS timestamp, cr.agent_id, cr.collector AS collector_name, "
                    f"cr.hostname, {username_col} AS username, cr.status, cr.payload_json "
                    + source +
                    "ORDER BY cr.collector_collected_at DESC, cr.id DESC"
                )
            res = storage._query(fb_sql, fb_params)
            if res and hasattr(res, 'result_rows'):
                pids = []
                for row in res.result_rows:
                    d = dict(zip(res.column_names, row))
                    eid = str(d.get('event_id', ''))
                    pid = str(d.get('payload_id') or '')
                    if pid:
                        pids.append(pid)
                    ts = d.get('timestamp')
                    ts_str = _utc_iso(ts)
                    cname = str(d.get('collector_name') or '')
                    raw_payload = d.get('payload_json')
                    preview = extract_summary_preview(cname, raw_payload)
                    events.append({
                        'event_id': eid,
                        'id': eid,
                        'payload_id': pid,
                        'timestamp': ts_str,
                        'collected_at': ts_str,
                        'agent_id': str(d.get('agent_id') or ''),
                        'collector_name': cname,
                        'collector': cname,
                        'hostname': str(d.get('hostname') or ''),
                        'username': str(d.get('username') or ''),
                        'status': str(d.get('status') or 'success'),
                        'summary_preview': preview,
                    })
                # Secondary fast lookup for usernames on returned limit rows only (pruned to recent partitions)
                if pids and not version2:
                    try:
                        valid_pids = [p for p in dict.fromkeys(pids) if p]
                        if valid_pids:
                            rp_res = storage._query(
                                "SELECT payload_id, argMin(username, received_at) AS username FROM raw_payloads WHERE received_at >= now() - INTERVAL 14 DAY AND payload_id IN %(pids)s GROUP BY payload_id",
                                {'pids': valid_pids}
                            )
                            if not rp_res or not getattr(rp_res, 'result_rows', None):
                                rp_res = storage._query(
                                    "SELECT payload_id, argMin(username, received_at) AS username FROM raw_payloads WHERE payload_id IN %(pids)s GROUP BY payload_id",
                                    {'pids': valid_pids}
                                )
                            if rp_res and hasattr(rp_res, 'result_rows'):
                                user_map = {r[0]: str(r[1] or '') for r in rp_res.result_rows}
                                for ev in events:
                                    if ev.get('payload_id') in user_map:
                                        ev['username'] = user_map[ev['payload_id']]
                    except Exception:
                        pass
        except Exception:
            pass

    has_more = len(events) > limit
    events = events[:limit]
    next_cursor = None
    if has_more and events:
        last = events[-1]
        next_cursor = encode_cursor('clickhouse', key, last['timestamp'], last['event_id'])

    return {
        'events': events,
        'logs': events,
        'next_cursor': next_cursor,
        'has_more': has_more,
        'limit': limit,
        'source': 'clickhouse',
    }


def telemetry_event_detail(storage, event_id: str) -> dict[str, Any] | None:
    """
    On-Demand Deep Forensic Telemetry Inspection.
    Fetches full raw payload, features, and risk event context only when analyst selects a row.
    """
    if not event_id or str(event_id).isdigit():
        return None

    import uuid as _uuid_mod
    try:
        _uuid_mod.UUID(str(event_id))
        id_clause_te = "event_id = toUUID(%(event_id)s)"
        id_clause_cr = "id = toUUID(%(event_id)s)"
    except (ValueError, TypeError, AttributeError):
        id_clause_te = "toString(event_id) = %(event_id)s"
        id_clause_cr = "toString(id) = %(event_id)s"

    row_data = None
    params = {'event_id': str(event_id)}

    # 1. Try telemetry_events
    try:
        sql = (
            "SELECT event_id, payload_id, agent_id, collector_name, timestamp, hostname, username, status, "
            f"summary_preview, raw_payload_json FROM telemetry_events WHERE {id_clause_te} LIMIT 1"
        )
        res = storage._query(sql, params)
        if res and res.result_rows:
            d = dict(zip(res.column_names, res.result_rows[0]))
            row_data = {
                'event_id': str(d.get('event_id')),
                'payload_id': str(d.get('payload_id') or ''),
                'agent_id': str(d.get('agent_id') or ''),
                'collector_name': str(d.get('collector_name') or ''),
                'timestamp': d.get('timestamp'),
                'hostname': str(d.get('hostname') or ''),
                'username': str(d.get('username') or ''),
                'status': str(d.get('status') or 'success'),
                'summary_preview': str(d.get('summary_preview') or ''),
                'raw_payload_json': d.get('raw_payload_json') or '{}',
            }
    except Exception:
        row_data = None

    # 2. Fallback to collector_results
    if not row_data:
        try:
            version2 = getattr(storage, 'collector_schema_version', 1) == 2
            if version2:
                source = f' FROM collector_events_v2 FINAL WHERE {id_clause_cr} '
                username_col = 'username'
            else:
                source = f' FROM collector_results WHERE {id_clause_cr} '
                username_col = "''"
            sql = (
                f"SELECT id AS event_id, payload_id, agent_id, collector AS collector_name, "
                f"collector_collected_at AS timestamp, hostname, {username_col} AS username, status, "
                f"payload_json AS raw_payload_json" + source + "LIMIT 1"
            )
            res = storage._query(sql, params)
            if res and res.result_rows:
                d = dict(zip(res.column_names, res.result_rows[0]))
                raw_payload = d.get('raw_payload_json') or '{}'
                pid = str(d.get('payload_id') or '')
                row_data = {
                    'event_id': str(d.get('event_id')),
                    'payload_id': pid,
                    'agent_id': str(d.get('agent_id') or ''),
                    'collector_name': str(d.get('collector_name') or ''),
                    'timestamp': d.get('timestamp'),
                    'hostname': str(d.get('hostname') or ''),
                    'username': str(d.get('username') or ''),
                    'status': str(d.get('status') or 'success'),
                    'summary_preview': extract_summary_preview(str(d.get('collector_name') or ''), raw_payload),
                    'raw_payload_json': raw_payload,
                }
                if pid and not version2:
                    try:
                        rp = storage._query("SELECT username FROM raw_payloads WHERE payload_id = %(pid)s LIMIT 1", {'pid': pid})
                        if rp and rp.result_rows:
                            row_data['username'] = str(rp.result_rows[0][0] or '')
                    except Exception:
                        pass
        except Exception:
            return None

    if not row_data:
        return None

    # Parse payload
    raw_json = row_data.get('raw_payload_json') or '{}'
    payload_obj = {}
    if isinstance(raw_json, str):
        try:
            payload_obj = json.loads(raw_json)
        except Exception:
            payload_obj = {'raw': raw_json}
    elif isinstance(raw_json, dict):
        payload_obj = raw_json

    ts = row_data.get('timestamp')
    ts_str = _utc_iso(ts)
    pid = row_data.get('payload_id')

    features = {}
    risk = {}
    if pid:
        date_bound_sql = ""
        bound_params = {'pid': pid}
        ts_dt = None
        if isinstance(ts, datetime):
            ts_dt = ts
        elif isinstance(ts, str):
            try:
                ts_dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
            except Exception:
                pass
        if ts_dt:
            from datetime import timedelta
            bound_params['ts_start'] = (ts_dt - timedelta(days=2)).strftime('%Y-%m-%d %H:%M:%S')
            bound_params['ts_end'] = (ts_dt + timedelta(days=2)).strftime('%Y-%m-%d %H:%M:%S')
            date_bound_sql = " AND created_at >= parseDateTime64BestEffort(%(ts_start)s, 3, 'UTC') AND created_at <= parseDateTime64BestEffort(%(ts_end)s, 3, 'UTC')"

        try:
            f_res = storage._query("SELECT feature_name, coalesce(feature_value_text, toString(feature_value_numeric)) "
                                   f"FROM normalized_features WHERE payload_id = %(pid)s{date_bound_sql} "
                                   "AND (feature_value_numeric IS NOT NULL OR feature_value_text != '')", bound_params)
            if f_res and hasattr(f_res, 'result_rows'):
                for fname, fval in f_res.result_rows:
                    if fval is not None and str(fval).lower() != 'none':
                        features[str(fname)] = fval
        except Exception:
            pass
        try:
            r_res = storage._query("SELECT risk_level, summary, correlated_signals_json, risk_score "
                                   f"FROM risk_events WHERE payload_id = %(pid)s{date_bound_sql} ORDER BY created_at DESC LIMIT 1", bound_params)
            if r_res and r_res.result_rows:
                r_fields = ('risk_level', 'summary', 'correlated_signals_json', 'risk_score')
                risk = dict(zip(r_fields, r_res.result_rows[0]))
        except Exception:
            pass

    return {
        'event_id': row_data['event_id'],
        'id': row_data['event_id'],
        'payload_id': pid,
        'agent_id': row_data['agent_id'],
        'collector_name': row_data['collector_name'],
        'collector': row_data['collector_name'],
        'timestamp': ts_str,
        'collected_at': ts_str,
        'hostname': row_data['hostname'],
        'username': row_data['username'],
        'status': row_data['status'],
        'summary_preview': row_data.get('summary_preview') or extract_summary_preview(row_data['collector_name'], payload_obj),
        'payload': payload_obj,
        'payload_json': raw_json if isinstance(raw_json, str) else json.dumps(raw_json),
        'features': features,
        'risk': risk,
    }


def telemetry_histogram(storage, time_range='1h', interval=None, collector=None, status=None,
                        agent_id=None, start_time=None, end_time=None):
    """
    Server-side Event Frequency Histogram Aggregation.
    Executes in < 5ms over millions of rows on ClickHouse columnar timestamps.
    Returns lightweight coordinates array for SVG/Canvas rendering.
    """
    range_map = {
        '15m': ("INTERVAL 15 MINUTE", "toStartOfMinute(timestamp)", "1m"),
        '1h': ("INTERVAL 1 HOUR", "toStartOfMinute(timestamp)", "1m"),
        '24h': ("INTERVAL 24 HOUR", "toStartOfInterval(timestamp, INTERVAL 15 MINUTE)", "15m"),
        '7d': ("INTERVAL 7 DAY", "toStartOfInterval(timestamp, INTERVAL 2 HOUR)", "2h"),
        'all': ("INTERVAL 30 DAY", "toStartOfDay(timestamp)", "1d"),
        'custom': (None, "toStartOfDay(timestamp)", "1d"),
    }
    int_map = {
        '1m': 'toStartOfMinute(timestamp)',
        '5m': 'toStartOfFiveMinutes(timestamp)',
        '10m': 'toStartOfTenMinutes(timestamp)',
        '15m': 'toStartOfInterval(timestamp, INTERVAL 15 MINUTE)',
        '1h': 'toStartOfHour(timestamp)',
        '2h': 'toStartOfInterval(timestamp, INTERVAL 2 HOUR)',
        '1d': 'toStartOfDay(timestamp)',
    }
    time_window, default_bucket_fn, default_interval = range_map.get(time_range, range_map['1h'])
    actual_interval = interval or default_interval
    bucket_fn = int_map.get(interval, default_bucket_fn) if interval else default_bucket_fn

    params = {}
    if time_range == 'custom':
        if start_time is None or end_time is None:
            raise ValueError('Custom histogram requires start and end times')
        params['start_time'], params['end_time'] = start_time, end_time
        clauses = ["timestamp >= %(start_time)s", "timestamp < %(end_time)s"]
    else:
        clauses = [f"timestamp >= now() - {time_window}"]
    if collector:
        params['collector'] = collector.strip().lower()
        clauses.append("lower(collector_name) = %(collector)s")
    if status:
        if status.lower() == 'error':
            clauses.append("lower(status) IN ('error', 'failed', 'critical', 'tampered')")
        else:
            params['status'] = status.lower()
            clauses.append("lower(status) = %(status)s")
    if agent_id:
        params['agent_id'] = str(agent_id)
        clauses.append("agent_id = %(agent_id)s")

    where = " WHERE " + " AND ".join(clauses)
    histogram = []
    total_events = 0

    def _format_iso(t_val):
        return _utc_iso(t_val)

    try:
        from server.storage.dashboard_rollups import enabled as rollups_enabled, names as rollup_names
        if rollups_enabled():
            source = rollup_names(getattr(storage, 'collector_schema_version', 1))[1]
            r_where = where.replace('timestamp', 'bucket').replace('collector_collected_at', 'bucket').replace('lower(collector_name)', 'collector')
            r_where = r_where.replace('now() -', 'toStartOfMinute(now()) -')
            r_bucket_fn = bucket_fn.replace('timestamp', 'bucket').replace('collector_collected_at', 'bucket')
            sql = (
                f"SELECT {r_bucket_fn} AS t, uniqExactMerge(event_ids) AS c "
                f"FROM {source}{r_where} "
                f"GROUP BY t ORDER BY t SETTINGS max_execution_time = 8, timeout_before_checking_execution_speed = 0"
            )
            res = storage._query(sql, params)
            if res and hasattr(res, 'result_rows'):
                for t_val, c_val in res.result_rows:
                    histogram.append({'timestamp': _format_iso(t_val), 'count': int(c_val)})
                    total_events += int(c_val)
            return {
                'ok': True,
                'time_range': time_range,
                'interval': actual_interval,
                'total_events': total_events,
                'histogram': histogram,
            }
    except TimeoutError:
        raise
    except Exception as rexc:
        logger.debug("Rollups query skipped or failed: %s", rexc)

    try:
        sql = (
            f"SELECT {bucket_fn} AS t, count() AS c "
            f"FROM telemetry_events{where} "
            f"GROUP BY t ORDER BY t SETTINGS max_execution_time = 10"
        )
        res = storage._query(sql, params)
        if res and hasattr(res, 'result_rows'):
            for t_val, c_val in res.result_rows:
                histogram.append({'timestamp': _format_iso(t_val), 'count': int(c_val)})
                total_events += int(c_val)
    except TimeoutError:
        raise
    except Exception as exc:
        logger.debug("Primary ClickHouse histogram query on telemetry_events note: %s", exc)
        # Fallback to collector_results if telemetry_events table doesn't exist
        try:
            fb_clauses = [
                c.replace('timestamp', 'collector_collected_at').replace('lower(collector_name)', 'lower(collector)')
                for c in clauses
            ]
            fb_bucket_fn = bucket_fn.replace('timestamp', 'collector_collected_at')
            fb_where = " WHERE " + " AND ".join(fb_clauses)
            source_table = "collector_events_v2" if getattr(storage, 'collector_schema_version', 1) == 2 else "collector_results"
            fb_sql = (
                f"SELECT {fb_bucket_fn} AS t, count() AS c "
                f"FROM {source_table}{fb_where} "
                f"GROUP BY t ORDER BY t SETTINGS max_execution_time = 10"
            )
            res = storage._query(fb_sql, params)
            if res and hasattr(res, 'result_rows'):
                for t_val, c_val in res.result_rows:
                    histogram.append({'timestamp': _format_iso(t_val), 'count': int(c_val)})
                    total_events += int(c_val)
        except TimeoutError:
            raise
        except Exception:
            pass

    return {
        'ok': True,
        'time_range': time_range,
        'interval': actual_interval,
        'total_events': total_events,
        'histogram': histogram,
    }
